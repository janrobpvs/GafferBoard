================================================================================
  GAFFERBOARD — Strategic Squad & Transfer Planner for Football Manager 27
  Version 1.0  |  Windows 10 / 11 (64-bit)
  Website: https://janrobpvs.github.io/GafferBoard/
================================================================================

1. SYSTEM REQUIREMENTS
----------------------
- Operating System : Windows 10 or Windows 11 (64-bit)
- Game             : Football Manager 27 installed locally on your PC
- Disk Space       :
    * EXE version         : ~19 MB file (~45 MB temporary space while running)
    * Portable ZIP version: ~65 MB free space temporarily during extraction
                            (~19 MB .zip + ~43 MB extracted folder until you
                            delete the .zip; ~43 MB after cleanup)
- Internet         : NOT required (100% offline; internet is only needed if you
                     choose to enable optional cloud AI reports: Gemini, ChatGPT
                     or Claude)
- Prerequisites    : None — no Python, Node.js, admin rights, or account needed.


2. INSTALLATION — STEP BY STEP
------------------------------
GafferBoard is available in two formats: a Windows EXE version and a Portable
ZIP version. Both run the exact same app — choose whichever you prefer.

OPTION A — WINDOWS EXE VERSION (Installer or Standalone .exe)
  1. Download the GafferBoard .exe file from the official website / GitHub Releases.
  2. Double-click the downloaded .exe file.
  3. If Windows SmartScreen appears ("Windows protected your PC"), click
     "More info" and then "Run anyway" (see Section 4 below for why this occurs).
  4. If using the Setup installer:
       - Follow the on-screen steps and choose your installation folder
         (default is your local user folder — no administrator password needed).
       - Launch GafferBoard from the Start Menu or Desktop shortcut.
     If using a standalone single-file .exe:
       - Move "GafferBoard.exe" into any permanent folder you like (for example
         C:\Tools\GafferBoard or Documents\GafferBoard) and double-click to run.
  5. Updating / Uninstalling:
       - Setup installer: uninstall anytime via Windows Settings -> Apps ->
         Installed apps -> GafferBoard. Your saved .json squad plans are kept.
       - Standalone .exe: simply replace the old .exe with the new one to update,
         or delete it to uninstall.

OPTION B — PORTABLE ZIP VERSION (No Installer)
  1. Download the GafferBoard .zip archive from the official website / GitHub Releases.
  2. IMPORTANT: Do NOT double-click GafferBoard.exe directly inside the ZIP file!
     Extract the archive first:
       - Right-click the .zip file in Windows File Explorer.
       - Click "Extract All...".
       - Choose a permanent folder on your PC (e.g. C:\Tools\GafferBoard or
         Documents\GafferBoard) and click "Extract".
  3. Open the extracted folder and keep all files and subfolders together
     (do not move GafferBoard.exe out of the folder on its own).
  4. Optional shortcut: right-click "GafferBoard.exe" -> "Show more options" ->
     "Send to" -> "Desktop (create shortcut)".
  5. Double-click "GafferBoard.exe" (or your Desktop shortcut) to launch.
     If Windows SmartScreen appears on first launch, click "More info" ->
     "Run anyway" (see Section 4).
  6. Updating / Uninstalling:
       - To update: extract the new ZIP to a fresh folder (your .json squad plans
         saved in your chosen plans folder are completely separate and untouched).
       - To uninstall: simply delete the extracted GafferBoard folder. Nothing is
         left behind in Windows or the registry.


3. FIRST LAUNCH & QUICK START
-----------------------------
  1. Open Settings -> "Load & Save" (opens automatically on first run).
  2. Under "Load from existing savegame (FM27)":
       - Step 1: GafferBoard automatically scans your standard Football Manager 27
         "games" folder (usually Documents\Sports Interactive\Football Manager 27\games).
         If your saves live elsewhere, click "Choose folder".
       - Step 2: Select your .fm savegame file.
       - Step 3: Click your active manager / club.
       - Step 4 (optional): Tick any .fmf shortlists you want to include.
       - Click "Load from FM27 savegame" (~10–15 seconds, 100% read-only).
  3. Under "Squad Planner Profiles":
       - Defaults to your savegame folder (click "Choose folder" if you prefer a
         separate folder for your 3-season .json plans).
       - Enter a plan name and click "Save". Next time, click any saved plan in
         the list to load it in 1 click.
  4. Tip: Look for the small "?" help icons on Load & Save, Preferences, and
     Pages 1–4 for quick guides. Switch language (English/Norwegian), currency
     (£/€/$/kr), wage display (weekly/monthly/yearly), autosave interval, custom
     FM graphics folder, or optional AI under Settings -> Preferences.
     Use Ctrl+Click on squad tabs in the Squad & Shortlist panel to view multiple
     squads together (e.g. First Team + U21), and use the Exit button in the top
     bar to save and close cleanly (prompts automatically on unsaved changes).
     Keyboard shortcuts: 1–4 (switch pages), Ctrl+Z / Ctrl+Y (Undo / Redo),
     Ctrl+S (Quick-save), Esc (close popups).


4. WINDOWS SMARTSCREEN & SECURITY ("NOT A VIRUS")
-------------------------------------------------
When running a newly released independent fan tool for the first time, Windows
Defender SmartScreen may show a blue notice:
  "Windows protected your PC — Unknown publisher"

Why does this happen?
- GafferBoard is a free, fan-made indie tool created by JRMP and is not signed
  with a paid commercial Microsoft EV code-signing certificate (which costs
  hundreds of dollars per year).
- Windows SmartScreen displays this warning for any new unsigned .exe until
  enough users have downloaded and run it.

How to allow it safely:
  1. Click "More info" in the SmartScreen dialog.
  2. Click "Run anyway".

Privacy & Safety Guarantee:
- 100% offline — zero telemetry, zero analytics, zero tracking, zero ads, and
  zero external network requests during normal use.
- 100% read-only access to your FM27 savegames, shortlists, logos, and facepacks:
  GafferBoard NEVER writes to or alters your Football Manager files.
- All your squad plans (.json), notes, and optional AI API keys stay strictly on
  your own PC. (External requests only occur if YOU choose to enter an AI API key
  for Gemini, OpenAI or Claude and run a Deep AI report, or click an external link
  in About GB.)


5. TROUBLESHOOTING (FAQ)
------------------------
- "My FM27 savegame folder was not detected automatically"
  -> Click "Choose folder" in Step 1 under Load & Save and browse to your FM27
     "games" folder (often inside Documents\Sports Interactive\Football Manager 27
     or OneDrive\Documents\Sports Interactive\Football Manager 27).

- "I extracted the ZIP, moved GafferBoard.exe to the Desktop, and it won't start"
  -> Put GafferBoard.exe back inside the extracted folder with all its supporting
     files, and create a Desktop shortcut instead.

- "Where are my squad plans and settings saved?"
  -> Your squad plans (.json) are saved in the folder you chose under Settings ->
     Load & Save -> Squad Planner Profiles. App preferences (language, theme, etc.)
     are stored locally in your Windows user profile.

- "Antivirus flagged or quarantined the file"
  -> False positives occasionally happen with newly packaged indie apps. Make sure
     you downloaded GafferBoard only from the official website / GitHub Releases
     below, and if needed add the GafferBoard folder to your antivirus exclusions.


6. REPORTING BUGS & FEEDBACK
----------------------------
Found a bug, a translation issue, or have an idea for a new FM27 feature?
- Official website & guides : https://janrobpvs.github.io/GafferBoard/
- Report issues & ideas     : https://github.com/janrobpvs/GafferBoard/issues

When reporting a bug, please include:
- Your GafferBoard version (shown under Settings -> About GB)
- Your FM27 version and language setting (English / Norwegian)
- Whether you use the EXE or Portable ZIP version
- A short description (and screenshot if possible) of what happened


7. LICENSE, PRIVACY & DISCLAIMER
--------------------------------
Copyright (c) 2026 GafferBoard · Created by JRMP. All Rights Reserved.
Unofficial fan-made tool — provided "as is", without warranty of any kind.
Not affiliated with, endorsed by, or connected to Sports Interactive or SEGA.
Football Manager is a registered trademark of Sports Interactive Ltd.

Included legal & privacy documents:
- LICENSE.txt              : Free personal-use license & warranty disclaimer
- PRIVACY.txt              : 100% offline / zero-telemetry privacy policy
- THIRD_PARTY_LICENSES.txt : Open-source library attributions (including fmsave
                             by Randal S. Olson, MIT License)

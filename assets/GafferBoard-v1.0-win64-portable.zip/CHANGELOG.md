# GafferBoard — Changelog & Release Notes

## v1.0 (Standalone Windows EXE & Portable ZIP Release)
*Target: Windows 10/11 (64-bit) · Tested on FM27*

### Highlights & Features
- **Direct FM27 Savegame & Shortlist Integration (100% Read-Only):**
  - Auto-scans your FM27 `games` and `shortlists` folders, detects active managers/clubs (including multiplayer saves), reads Tactics 1–3, player stats, contracts, club finances, injury history, club logos, manager portraits, and player Cut-Out facepacks (`FM27\graphics\faces`).
  - Automatically detects club-specific reserve/youth squad names and age caps (e.g. `U21`, `U20`, `U19`, `U23`, `II`, `B`, `U18`) directly from your FM27 savegame.
  - Top-bar **Refresh** updates live contracts, values, and game date without overwriting your formations, status tags, or notes.
- **FM27 Visual Theme:**
  - Graphite + Magenta FM27 palette, club-colored top accents and KPI tiles, 2D grass stripes and Defend/Support/Attack duty indicators on the tactics pitch, FM27 green/lime/amber position chips, and crisp 5-star gold AstMan ratings.
- **3-Season Strategic Planner (First Team, Reserve/Youth & Loans):**
  - **1. Lineup Overview:** Build 1st-, 2nd- and 3rd-choice depth charts with drag-and-drop, directional hover expansion, clickable slot pickers, PNG depth chart export, and season transition highlights.
  - **2. Squad-building & Transfers:** Side-by-side outgoing sales, loans (treated strictly as a status tied to each player's home squad), decimal sale fees (e.g. `12.5`), and replacement planning with the **Sporting Director Replacement Matcher** (natural position matching, SD Auto + Custom Priorities, Min–Max age filter, side-by-side player comparison, and hover Match Score Breakdown).
  - **3. Transfer Windows:** Chronological window overview anchored to your in-game FM27 date with **Live FM27 Budget & Wage Simulator**.
  - **4. Squad Analysis:** Multi-season KPI tiles, Squad Rating breakdown & improvement tips, Age Distribution, Strength by Unit, HGN/HGC Registration Quotas, **Shortlist Quality & Position Gaps** (Now ★, Potential PA★, and upcoming 1–2 season gaps sorted by standard position order), Youth Promotion / Loan Return Radar with 1-click pre-filled actions, Season Performance, Club Finances, Injury Risk, and optional Deep AI review & interactive **Ask SD** chat (Google Gemini, OpenAI ChatGPT, Anthropic Claude, or local Ollama) with **Manager Philosophy** and persistent **SD Memory**.
- **Squad & Shortlist Panel:**
  - `All` defaults to own-club squads (click again to toggle `All + SL`), **Ctrl+Click** multi-selects squads (e.g. First Team + U21), and `Loans` scopes automatically to the selected squad(s).
- **Manager & Club Profile:**
  - Displays manager photo, finances, key backroom staff, all 14 FM27 coaching/mental attributes with **development history tracking**, and Manager Philosophy.
- **Real Folder-Based Squad Plans (.json), Autosave & Safe Exit:**
  - Built-in folder browser with Quick Access, Drives, and subfolder creation. Configurable **Autosave** (default 5 min), quick-save (`Ctrl+S`), Undo/Redo (`Ctrl+Z`/`Ctrl+Y`), and top-bar **Exit** button with unsaved-changes detection (**Save & Exit**).
- **Full English & Norwegian Localization + Uniform `?` Quick Guides:**
  - 100% offline with zero telemetry, zero ads, and zero external requests during normal use.

---

## v0.95 (Pre-1.0 Development Milestone)
- Completed FM27 savegame reader (`fmsave`), multi-season depth charts, transfer simulator, Page 4 analytics, AI Sporting Director, and full EN/NO localization.

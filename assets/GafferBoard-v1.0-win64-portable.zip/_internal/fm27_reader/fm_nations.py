"""
Sports Interactive universal Football Manager Nation database_id lookup table.
Maps Nation.database_id -> (3-letter code, country name, is_eu_eea).
"""

# EU27 + EEA (Norway, Iceland, Liechtenstein) + Switzerland
EU_EEA_DB_IDS = {
    755,  # Austria
    757,  # Belgium
    760,  # Bulgaria
    761,  # Croatia
    762,  # Cyprus
    763,  # Czech Republic
    764,  # Denmark
    766,  # Estonia
    768,  # Finland
    769,  # France
    771,  # Germany
    772,  # Greece
    773,  # Hungary
    774,  # Iceland (EEA)
    789,  # Republic of Ireland
    776,  # Italy
    777,  # Latvia
    778,  # Liechtenstein (EEA)
    779,  # Lithuania
    780,  # Luxembourg
    782,  # Malta
    784,  # Netherlands
    786,  # Norway (EEA)
    787,  # Poland
    788,  # Portugal
    790,  # Romania
    794,  # Slovakia
    795,  # Slovenia
    796,  # Spain
    797,  # Sweden
    798,  # Switzerland
}

FM_NATIONS = {
    # Africa (1-55)
    1: ("ALG", "Algeria"),
    2: ("ANG", "Angola"),
    3: ("BEN", "Benin"),
    4: ("BOT", "Botswana"),
    5: ("BFA", "Burkina Faso"),
    6: ("BDI", "Burundi"),
    7: ("CMR", "Cameroon"),
    8: ("CPV", "Cape Verde"),
    9: ("CTA", "Central African Rep."),
    10: ("CHA", "Chad"),
    11: ("CGO", "Congo"),
    12: ("DJI", "Djibouti"),
    13: ("EGY", "Egypt"),
    14: ("EQG", "Equatorial Guinea"),
    15: ("ERI", "Eritrea"),
    16: ("ETH", "Ethiopia"),
    17: ("GAB", "Gabon"),
    18: ("GAM", "Gambia"),
    21: ("GHA", "Ghana"),
    22: ("GUI", "Guinea"),
    23: ("GNB", "Guinea-Bissau"),
    24: ("CIV", "Ivory Coast"),
    25: ("KEN", "Kenya"),
    26: ("LES", "Lesotho"),
    27: ("LBR", "Liberia"),
    28: ("LBY", "Libya"),
    29: ("MAD", "Madagascar"),
    30: ("MWI", "Malawi"),
    31: ("MLI", "Mali"),
    32: ("MTN", "Mauritania"),
    33: ("MRI", "Mauritius"),
    34: ("MAR", "Morocco"),
    35: ("MOZ", "Mozambique"),
    36: ("NAM", "Namibia"),
    37: ("NIG", "Niger"),
    38: ("NGA", "Nigeria"),
    39: ("RWA", "Rwanda"),
    40: ("STP", "São Tomé"),
    41: ("SEN", "Senegal"),
    42: ("SEY", "Seychelles"),
    43: ("SLE", "Sierra Leone"),
    44: ("SOM", "Somalia"),
    45: ("RSA", "South Africa"),
    46: ("SDN", "Sudan"),
    47: ("SWZ", "Eswatini"),
    48: ("TAN", "Tanzania"),
    49: ("TOG", "Togo"),
    50: ("TUN", "Tunisia"),
    51: ("UGA", "Uganda"),
    52: ("ZAM", "Zambia"),
    53: ("COD", "DR Congo"),
    54: ("ZIM", "Zimbabwe"),
    55: ("COM", "Comoros"),

    # Asia (100-150)
    103: ("AFG", "Afghanistan"),
    104: ("BHR", "Bahrain"),
    105: ("BAN", "Bangladesh"),
    106: ("BHU", "Bhutan"),
    107: ("BRU", "Brunei"),
    108: ("CAM", "Cambodia"),
    109: ("TPE", "Chinese Taipei"),
    110: ("CHN", "China"),
    111: ("GUM", "Guam"),
    112: ("HKG", "Hong Kong"),
    113: ("IND", "India"),
    114: ("IDN", "Indonesia"),
    115: ("IRN", "Iran"),
    116: ("IRQ", "Iraq"),
    117: ("JPN", "Japan"),
    118: ("JOR", "Jordan"),
    119: ("KAZ", "Kazakhstan"),
    120: ("KUW", "Kuwait"),
    121: ("KGZ", "Kyrgyzstan"),
    122: ("LAO", "Laos"),
    123: ("LBN", "Lebanon"),
    124: ("MAC", "Macau"),
    125: ("MAS", "Malaysia"),
    126: ("MDV", "Maldives"),
    127: ("MNG", "Mongolia"),
    128: ("MYA", "Myanmar"),
    129: ("NEP", "Nepal"),
    130: ("PRK", "North Korea"),
    131: ("OMA", "Oman"),
    132: ("PAK", "Pakistan"),
    133: ("PLE", "Palestine"),
    134: ("PHI", "Philippines"),
    135: ("QAT", "Qatar"),
    136: ("KSA", "Saudi Arabia"),
    137: ("SGP", "Singapore"),
    138: ("KOR", "South Korea"),
    139: ("SRI", "Sri Lanka"),
    140: ("SYR", "Syria"),
    141: ("TJK", "Tajikistan"),
    142: ("THA", "Thailand"),
    143: ("TKM", "Turkmenistan"),
    144: ("UAE", "UAE"),
    145: ("UZB", "Uzbekistan"),
    146: ("VIE", "Vietnam"),
    147: ("YEM", "Yemen"),
    1440: ("AUS", "Australia"),

    # North & Central America / Caribbean (350-405)
    361: ("BER", "Bermuda"),
    364: ("CAN", "Canada"),
    366: ("CRC", "Costa Rica"),
    367: ("CUB", "Cuba"),
    369: ("DOM", "Dominican Rep."),
    370: ("SLV", "El Salvador"),
    371: ("GRN", "Grenada"),
    372: ("GUA", "Guatemala"),
    373: ("GUY", "Guyana"),
    374: ("HAI", "Haiti"),
    375: ("HON", "Honduras"),
    376: ("JAM", "Jamaica"),
    377: ("MEX", "Mexico"),
    379: ("CUW", "Curaçao"),
    380: ("NCA", "Nicaragua"),
    381: ("PAN", "Panama"),
    382: ("PUR", "Puerto Rico"),
    387: ("SUR", "Suriname"),
    388: ("TRI", "Trinidad & Tobago"),
    390: ("USA", "USA"),

    # Europe (750-805 + newer UEFA members)
    752: ("ALB", "Albania"),
    753: ("AND", "Andorra"),
    754: ("ARM", "Armenia"),
    755: ("AUT", "Austria"),
    756: ("AZE", "Azerbaijan"),
    757: ("BEL", "Belgium"),
    758: ("BLR", "Belarus"),
    759: ("BIH", "Bosnia & Herz."),
    760: ("BUL", "Bulgaria"),
    761: ("CRO", "Croatia"),
    762: ("CYP", "Cyprus"),
    763: ("CZE", "Czech Republic"),
    764: ("DEN", "Denmark"),
    765: ("ENG", "England"),
    766: ("EST", "Estonia"),
    767: ("FRO", "Faroe Islands"),
    768: ("FIN", "Finland"),
    769: ("FRA", "France"),
    770: ("GEO", "Georgia"),
    771: ("GER", "Germany"),
    772: ("GRE", "Greece"),
    773: ("HUN", "Hungary"),
    774: ("ISL", "Iceland"),
    775: ("ISR", "Israel"),
    776: ("ITA", "Italy"),
    777: ("LVA", "Latvia"),
    778: ("LIE", "Liechtenstein"),
    779: ("LTU", "Lithuania"),
    780: ("LUX", "Luxembourg"),
    781: ("MKD", "North Macedonia"),
    782: ("MLT", "Malta"),
    783: ("MDA", "Moldova"),
    784: ("NED", "Netherlands"),
    785: ("NIR", "Northern Ireland"),
    786: ("NOR", "Norway"),
    787: ("POL", "Poland"),
    788: ("POR", "Portugal"),
    789: ("IRL", "Ireland"),
    790: ("ROU", "Romania"),
    791: ("RUS", "Russia"),
    792: ("SMR", "San Marino"),
    793: ("SCO", "Scotland"),
    794: ("SVK", "Slovakia"),
    795: ("SVN", "Slovenia"),
    796: ("ESP", "Spain"),
    797: ("SWE", "Sweden"),
    798: ("SUI", "Switzerland"),
    799: ("TUR", "Turkey"),
    800: ("UKR", "Ukraine"),
    801: ("WAL", "Wales"),
    802: ("SRB", "Serbia"),
    62002127: ("MNE", "Montenegro"),
    2000018082: ("KOS", "Kosovo"),
    91000000: ("GIB", "Gibraltar"),

    # Oceania
    1436: ("NZL", "New Zealand"),

    # South America (1649-1658)
    1649: ("ARG", "Argentina"),
    1650: ("BOL", "Bolivia"),
    1651: ("BRA", "Brazil"),
    1652: ("CHI", "Chile"),
    1653: ("COL", "Colombia"),
    1654: ("ECU", "Ecuador"),
    1655: ("PAR", "Paraguay"),
    1656: ("PER", "Peru"),
    1657: ("URU", "Uruguay"),
    1658: ("VEN", "Venezuela"),
}

# Club Nation database_id -> app leagueKey
CLUB_NATION_TO_LEAGUE_KEY = {
    765: "premier_league",
    796: "la_liga",
    771: "bundesliga",
    776: "serie_a",
    769: "ligue_1",
    784: "eredivisie",
    788: "liga_portugal",
    786: "eliteserien",
    797: "allsvenskan",
}


def resolve_nation(db_id):
    if db_id is None:
        return ""
    entry = FM_NATIONS.get(db_id)
    if entry:
        return entry[0]  # 3-letter FIFA code e.g. ENG, NOR, BEL
    return f"ID:{db_id}"


def is_eu_national(primary_db_id, second_db_ids):
    if primary_db_id in EU_EEA_DB_IDS:
        return "Ja"
    for sid in second_db_ids or ():
        if sid in EU_EEA_DB_IDS:
            return "Ja"
    return "Nei" if primary_db_id is not None else ""

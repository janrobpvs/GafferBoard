"""
FM27 Savegame + .fmf Shortlist reader powered by fmsave (read-only).
Reads a .fm save file and optional .fmf shortlist files and outputs JSON
for FM27 Squad Planner.
"""
import argparse
import dataclasses
import datetime
import json
import os
import re
import struct
import sys
import warnings

warnings.filterwarnings("ignore")

import fmsave
from fmsave import _version as vmod
from fmsave.readers import managed as mmod, tactics as tmod
from fmsave.readers._common import SAVE_SUMMARY_SECTION, TACTICS_SECTION
from fm_nations import CLUB_NATION_TO_LEAGUE_KEY, is_eu_national, resolve_nation

try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
except ImportError:
    Cipher = None

try:
    import zstandard as zstd
except ImportError:
    zstd = None


def patch_multimanager_summary_clock():
    """Allow fmsave to open multi-manager FM27 saves (e.g. 3 human managers) cleanly."""
    orig_read_clock = vmod.read_summary_clock

    def patched_read_clock(summary, layout, version):
        res = orig_read_clock(summary, layout, version)
        if res is not None:
            return res
        try:
            _, off = vmod.read_length_prefixed_string(
                summary, layout.structured_strings_offset, layout.max_setup_string_bytes
            )
            _, off = vmod.read_length_prefixed_string(summary, off, layout.max_version_bytes)
            div_count = vmod.read_u32(summary, off)
            off += 4
            for _ in range(min(div_count, layout.max_divisions)):
                _, off = vmod.read_length_prefixed_string(summary, off, layout.max_summary_name_bytes)
            for pos in range(off, len(summary) - 8):
                d = vmod.decode_date(summary, pos)
                if d is not None and 2024 <= d.year <= 2060:
                    return d, vmod.decode_time_slot(summary, pos)
        except Exception:
            pass
        return datetime.date(2026, 7, 1), 0

    vmod.read_summary_clock = patched_read_clock


def decrypt_aes_ctr(key: bytes, iv: bytes, ciphertext: bytes) -> bytes:
    if Cipher is None:
        raise RuntimeError("cryptography-pakken mangler for .fmf-dekryptering")
    cipher = Cipher(algorithms.AES(key), modes.CTR(iv))
    dec = cipher.decryptor()
    return dec.update(ciphertext) + dec.finalize()


def zstd_decompress_any(buf: bytes) -> bytes:
    if zstd is None:
        raise RuntimeError("zstandard-pakken mangler")
    dctx = zstd.ZstdDecompressor()
    import io
    with dctx.stream_reader(io.BytesIO(buf)) as reader:
        return reader.read()


def parse_fmf_shortlist(path: str):
    """Decrypt & unpack an FM27 .fmf shortlist file -> (shortlist_name, [unique_ids])."""
    with open(path, "rb") as f:
        data = f.read()

    if len(data) < 40:
        return os.path.splitext(os.path.basename(path))[0], []

    magic = data[2:6]
    # Find ZSTD directory footer
    zstd_magic = b"\x28\xb5\x2f\xfd"
    dir_pos = data.rfind(zstd_magic)
    if dir_pos < 0 or zstd is None:
        return os.path.splitext(os.path.basename(path))[0], []

    dir_raw = zstd_decompress_any(data[dir_pos:])

    # Parse .slf entry from directory table: find ".slf" marker
    slf_marker = b"\x04\x00\x00\x00.slf"
    slf_idx = dir_raw.find(slf_marker)
    if slf_idx < 0:
        return os.path.splitext(os.path.basename(path))[0], []

    after = slf_idx + len(slf_marker)
    entry_offset, comp_size, _uncomp_size = struct.unpack_from("<QQQ", dir_raw, after)
    data_start = 26
    rec = data[data_start + entry_offset : data_start + entry_offset + comp_size]

    if magic == b"afe.":
        k_len, iv_len = struct.unpack_from("<II", rec, 0)
        key = rec[8 : 8 + k_len]
        iv = rec[8 + k_len : 8 + k_len + iv_len]
        ct = rec[8 + k_len + iv_len :]
        plain = decrypt_aes_ctr(key, iv, ct)
    else:
        plain = rec

    if plain[:4] == zstd_magic:
        plain = zstd_decompress_any(plain)

    if len(plain) < 25 or plain[2:6] != b"fls.":
        return os.path.splitext(os.path.basename(path))[0], []

    name_len = struct.unpack_from("<I", plain, 13)[0]
    sl_name = plain[17 : 17 + name_len].decode("utf-8", errors="replace").strip()
    if not sl_name:
        sl_name = os.path.splitext(os.path.basename(path))[0]
    count_off = 17 + name_len
    count = struct.unpack_from("<I", plain, count_off)[0]
    uids = []
    pos = count_off + 4
    for _ in range(count):
        if pos + 4 > len(plain):
            break
        uids.append(struct.unpack_from("<I", plain, pos)[0])
        pos += 4
    return sl_name, uids


def format_gbp_millions(val):
    if not val or val <= 0:
        return "£0M"
    if val >= 1_000_000:
        m = val / 1_000_000.0
        rounded = round(m, 1)
        if rounded == int(rounded):
            return f"£{int(rounded)}M"
        return f"£{rounded}M"
    if val >= 1_000:
        k = int(round(val / 1_000.0))
        return f"£{k}K"
    return f"£{int(val)}"


def format_wage(wage):
    if not wage or wage <= 0:
        return ""
    return f"£{int(wage):,} p/w"


def make_short_name(first_name: str, last_name: str, full_name: str) -> str:
    fn = (first_name or "").strip()
    ln = (last_name or "").strip()
    full = (full_name or f"{fn} {ln}").strip()
    if fn and ln and fn.lower() != ln.lower():
        return f"{fn[0].upper()}.{ln}"
    tokens = full.split()
    if len(tokens) >= 2:
        return f"{tokens[0][0].upper()}.{' '.join(tokens[1:])}"
    return full or "Ukjent"


POS_CODE_MAP = {
    "GK": "GK",
    "DL": "DL",
    "WBL": "WBL",
    "DC": "DC",
    "DR": "DR",
    "WBR": "WBR",
    "DM": "DM",
    "ML": "ML",
    "MC": "MC",
    "MR": "MR",
    "AML": "AML",
    "AMC": "AMC",
    "AMR": "AMR",
    "STC": "SC",
    "ST": "SC",
}

POS_ATTR_PAIRS = [
    ("gk", "GK"), ("dl", "DL"), ("wbl", "WBL"), ("dc", "DC"),
    ("dr", "DR"), ("wbr", "WBR"), ("dm", "DM"), ("ml", "ML"),
    ("mc", "MC"), ("mr", "MR"), ("aml", "AML"), ("amc", "AMC"),
    ("amr", "AMR"), ("stc", "SC"),
]


def extract_natural_positions(player) -> list[str]:
    """Return ONLY the player's natural position(s) (FM rating >= 18 / natural_positions)."""
    ordered = []
    seen = set()

    def add_pos(raw_code):
        mapped = POS_CODE_MAP.get(str(raw_code).upper())
        if mapped and mapped not in seen:
            seen.add(mapped)
            ordered.append(mapped)

    for p in getattr(player, "natural_positions", ()) or ():
        add_pos(p)

    pos_obj = getattr(player, "positions", None)
    if pos_obj is not None:
        scored = []
        for attr, code in POS_ATTR_PAIRS:
            val = getattr(pos_obj, attr, 0) or 0
            if val >= 18:
                scored.append((val, code))
        scored.sort(key=lambda x: -x[0])
        for _, code in scored:
            add_pos(code)

    # Fallback: highest-rated single position if no explicit >= 18 natural position exists
    if not ordered and pos_obj is not None:
        best_val, best_code = 0, None
        for attr, code in POS_ATTR_PAIRS:
            val = getattr(pos_obj, attr, 0) or 0
            if val > best_val:
                best_val, best_code = val, code
        if best_code:
            ordered.append(best_code)

    return ordered


def extract_positions(player) -> list[str]:
    ordered = []
    seen = set()

    def add_pos(raw_code):
        mapped = POS_CODE_MAP.get(str(raw_code).upper())
        if mapped and mapped not in seen:
            seen.add(mapped)
            ordered.append(mapped)

    for p in extract_natural_positions(player):
        add_pos(p)
    for p in getattr(player, "accomplished_positions", ()) or ():
        add_pos(p)

    # Also include any position with rating >= 15 from Positions struct
    pos_obj = getattr(player, "positions", None)
    if pos_obj is not None:
        scored = []
        for attr, code in POS_ATTR_PAIRS:
            val = getattr(pos_obj, attr, 0) or 0
            if val >= 15:
                scored.append((val, code))
        scored.sort(key=lambda x: -x[0])
        for _, code in scored:
            add_pos(code)

    return ordered or ["MC"]


def ability_to_astman_stars(raw_ability, squad_anchor: float) -> float:
    """
    Convert internal ability into Assistant Manager relative star rating (0.5 - 5.0 in 0.5 steps).
    Raw 1-200 numbers are NEVER emitted to the UI.
    """
    if not raw_ability or raw_ability <= 0:
        return 2.5
    # 3.5 stars ~ club first-team anchor; every 10 points ~ 0.5 star
    stars = 3.5 + ((float(raw_ability) - squad_anchor) / 20.0)
    rounded = round(stars * 2.0) / 2.0
    return max(0.5, min(5.0, rounded))


def build_player_record(
    player,
    squad_label: str,
    status_label: str,
    my_club_uid: int,
    my_club_nation_id: int,
    squad_anchor: float,
    nation_id_to_db: dict,
    shortlist_name: str = "",
    home_squad: str = "",
    is_loaned: bool = False,
    stats_lookup: dict | None = None,
    injury_lookup: dict | None = None,
    default_contract_year: int = 2029,
):
    contract = getattr(player, "contract", None)
    c_end = getattr(contract, "end", None) if contract else None
    contract_year = c_end.year if c_end else default_contract_year
    contract_expires = c_end.strftime("%d.%m.%Y") if c_end else ""
    wage = getattr(contract, "wage", 0) if contract else 0
    ss_obj = getattr(contract, "squad_status", None) if contract else None
    ss_name = getattr(getattr(ss_obj, "label", None), "name", "") or ""
    squad_status_label = ss_name.replace("_", " ").title() if ss_name else ""

    lf = int(getattr(player, "left_foot", 0) or 0)
    rf = int(getattr(player, "right_foot", 0) or 0)
    if lf >= 15 and rf >= 15:
        strong_foot = "Either"
    elif lf > rf:
        strong_foot = "Left"
    else:
        strong_foot = "Right"

    hg_clubs = getattr(player, "home_grown_club_uids", ()) or ()
    hg_nations = getattr(player, "home_grown_nation_ids", ()) or ()
    if my_club_uid in hg_clubs:
        hg = "HGC"
    elif my_club_nation_id and my_club_nation_id in hg_nations:
        hg = "HGN"
    else:
        hg = "Foreign"

    ability = getattr(player, "ability", None)
    cur_raw = getattr(ability, "current", None) if ability else None
    pot_raw = getattr(ability, "potential", None) if ability else None
    ca_stars = ability_to_astman_stars(cur_raw, squad_anchor)
    pa_stars = max(ca_stars, ability_to_astman_stars(pot_raw or cur_raw, squad_anchor))

    dob_obj = getattr(player, "birth_date", None)
    dob_str = dob_obj.strftime("%d.%m.%Y") if dob_obj else ""

    first_name = getattr(player, "first_name", "") or ""
    last_name = getattr(player, "last_name", "") or ""
    full_name = getattr(player, "full_name", "") or getattr(player, "name", "") or ""
    short_name = make_short_name(first_name, last_name, full_name)

    val_str = format_gbp_millions(getattr(player, "transfer_value", None))
    unique_id = getattr(player, "unique_id", None) or getattr(player, "uid", None)
    club_name = getattr(player, "club_name", "") or ""

    # Resolve Nation + Second Nation + EU/EEA citizenship from universal FM database_id
    pri_nid = getattr(player, "nation_id", None)
    pri_db = nation_id_to_db.get(pri_nid) if pri_nid is not None else None
    sec_nids = getattr(player, "second_nation_ids", ()) or ()
    sec_dbs = [nation_id_to_db.get(sn) for sn in sec_nids if nation_id_to_db.get(sn) is not None and nation_id_to_db.get(sn) != pri_db]
    nat_str = resolve_nation(pri_db)
    second_nat_str = ", ".join(dict.fromkeys(resolve_nation(d) for d in sec_dbs if resolve_nation(d)))
    eu_str = is_eu_national(pri_db, sec_dbs)

    loan_end_obj = getattr(player, "loan_end", None) or (
        getattr(contract, "loan_end", None) if contract else None
    )
    loan_end_str = loan_end_obj.strftime("%d.%m.%Y") if loan_end_obj else ""

    p_uid_key = getattr(player, "uid", None)
    st_rec = None
    if stats_lookup:
        st_rec = stats_lookup.get(p_uid_key) or stats_lookup.get(unique_id)
    inj_count = 0
    if injury_lookup:
        inj_count = int(injury_lookup.get(p_uid_key) or injury_lookup.get(unique_id) or 0)

    return {
        "id": f"fm-{unique_id}",
        "uid": str(unique_id),
        "name": short_name,
        "fullName": full_name,
        "firstName": first_name,
        "lastName": last_name,
        "number": 0,
        "dob": dob_str,
        "baseAge": int(getattr(player, "age", 20) or 20),
        "contract": int(contract_year),
        "contractExpires": contract_expires,
        "value": val_str,
        "wage": format_wage(wage),
        "ca": ca_stars,
        "pa": pa_stars,
        "status": status_label,
        "isLoaned": bool(is_loaned),
        "squad": squad_label,
        "homeSquad": home_squad or (squad_label if squad_label in ("A-stall", "U21", "U18") else ""),
        "squadStatus": squad_status_label,
        "strongFoot": strong_foot,
        "leftFoot": lf,
        "rightFoot": rf,
        "avgRating": st_rec.get("avgRating") if st_rec else None,
        "seasonApps": st_rec.get("apps", 0) if st_rec else 0,
        "seasonMinutes": st_rec.get("minutes", 0) if st_rec else 0,
        "seasonGoals": st_rec.get("goals", 0) if st_rec else 0,
        "seasonAssists": st_rec.get("assists", 0) if st_rec else 0,
        "injuryCount": inj_count,
        "shortlistName": shortlist_name,
        "hg": hg,
        "nat": nat_str,
        "secondNation": second_nat_str,
        "euNational": eu_str,
        "club": club_name,
        "loanClub": club_name if is_loaned else "",
        "loanEnd": loan_end_str if is_loaned else "",
        "positions": extract_positions(player),
        "naturalPositions": extract_natural_positions(player) or extract_positions(player)[:1],
        "saleWindow": "Ingen",
        "saleYear": "",
        "salePrice": val_str if squad_label == "Shortlist" else "",
        "note": "",
    }


def read_all_human_managers(save):
    """Extract all active human managers & their clubs from save_game_summary (works for multi-manager saves)."""
    results = []
    seen_uids = set()
    try:
        ctx = save._context
        ci = ctx.club_index()
        layouts = mmod.find_managed_club_layouts(ctx.info.section_schemas, ctx.info.build)
        slay = next(
            getattr(layouts, f.name)
            for f in dataclasses.fields(layouts)
            if isinstance(getattr(layouts, f.name), mmod.SummaryStringsLayout)
        )
        with ctx.section(SAVE_SUMMARY_SECTION) as summary:
            links = mmod._summary_links(summary, slay, ci)
        for lk in links:
            if lk.club and lk.club.uid not in seen_uids:
                seen_uids.add(lk.club.uid)
                results.append(
                    {
                        "clubUid": int(lk.club.uid),
                        "clubName": lk.club.name or lk.club.short_name or f"Club {lk.club.uid}",
                        "clubShortName": lk.club.short_name or lk.club.name or f"Club {lk.club.uid}",
                        "managerName": lk.manager_name or "",
                    }
                )
    except Exception:
        pass

    if not results:
        try:
            for m in save.managed_clubs():
                if m.club_uid not in seen_uids:
                    seen_uids.add(m.club_uid)
                    results.append(
                        {
                            "clubUid": int(m.club_uid),
                            "clubName": m.club_name,
                            "clubShortName": m.club_short_name or m.club_name,
                            "managerName": m.manager_name or "",
                        }
                    )
        except Exception:
            pass
    return results


def raw_positions_to_grid_slots(raw_codes: list[int], prefix: str = "t") -> list[dict]:
    """Map 11 FM27 raw tactic position codes (0..14) onto the app's 6x5 tactical pitch grid."""
    counts = {}
    for code in raw_codes:
        counts[code] = counts.get(code, 0) + 1

    # Horizontal distribution for central lines (1, 2, or 3 players on the same row)
    CENTER_SPECS = {
        4: {  # DC (row 4)
            1: [("DC", "BCB", "CB", 4, 2)],
            2: [("DCL", "BCB", "CB", 4, 1), ("DCR", "BCB", "CB", 4, 3)],
            3: [("DCL", "CB", "CCB", 4, 1), ("DC", "BCB", "CB", 4, 2), ("DCR", "CB", "SCB", 4, 3)],
        },
        7: {  # DM (row 3)
            1: [("DM", "Anchor", "DM", 3, 2)],
            2: [("DMCL", "DLP", "DM", 3, 1), ("DMCR", "BBM", "DM", 3, 3)],
            3: [("DMCL", "DLP", "DM", 3, 1), ("DM", "Anchor", "DM", 3, 2), ("DMCR", "BBM", "DM", 3, 3)],
        },
        10: {  # MC (row 2)
            1: [("MC", "CM", "CM", 2, 2)],
            2: [("MCL", "CHM", "CM", 2, 1), ("MCR", "CHM", "CM", 2, 3)],
            3: [("MCL", "CM", "CM", 2, 1), ("MC", "DLP", "CM", 2, 2), ("MCR", "CM", "CM", 2, 3)],
        },
        13: {  # AMC (row 1)
            1: [("AMC", "AM", "AM", 1, 2)],
            2: [("AMCL", "SS", "AM", 1, 1), ("AMCR", "AP", "AM", 1, 3)],
            3: [("AMCL", "SS", "AM", 1, 1), ("AMC", "AM", "AM", 1, 2), ("AMCR", "AP", "AM", 1, 3)],
        },
        14: {  # SC (row 0)
            1: [("SC", "CFD", "CFD", 0, 2)],
            2: [("STL", "AF", "CF", 0, 1), ("STR", "PF", "CF", 0, 3)],
            3: [("STL", "AF", "CF", 0, 1), ("SC", "CFD", "CF", 0, 2), ("STR", "PF", "CF", 0, 3)],
        },
    }
    FIXED_SPEC = {
        0: ("GK", "GK", "GK", 5, 2),
        3: ("DL", "FB", "FB", 4, 0),
        2: ("DR", "FB", "FB", 4, 4),
        6: ("WBL", "WB", "WB", 3, 0),
        5: ("WBR", "WB", "WB", 3, 4),
        9: ("ML", "WM", "WM", 2, 0),
        8: ("MR", "WM", "WM", 2, 4),
        12: ("AML", "IF", "W", 1, 0),
        11: ("AMR", "W", "W", 1, 4),
    }

    used_center_idx = {}
    slots = []
    used_coords = set()

    for code in raw_codes:
        if code in CENTER_SPECS:
            n = min(3, max(1, counts.get(code, 1)))
            idx = used_center_idx.get(code, 0)
            used_center_idx[code] = idx + 1
            spec_list = CENTER_SPECS[code][n]
            spec = spec_list[min(idx, len(spec_list) - 1)]
        elif code in FIXED_SPEC:
            spec = FIXED_SPEC[code]
        else:
            spec = ("MC", "CM", "CM", 2, 2)

        pos, ip, oop, row, col = spec
        # Prevent duplicate coordinates if a tactic has e.g. 2x same wing slot
        if (row, col) in used_coords:
            for alt_col in (2, 1, 3, 0, 4):
                if (row, alt_col) not in used_coords:
                    col = alt_col
                    break
        used_coords.add((row, col))
        slots.append(
            {
                "slotId": f"{prefix}_{len(slots) + 1}",
                "pos": pos,
                "ip": ip,
                "oop": oop,
                "row": row,
                "col": col,
                "c1": [],
                "c2": [],
                "c3": [],
                "loan": [],
                "u21": [],
                "u21_c2": [],
                "u21_c3": [],
                "u21_loan": [],
                "u19": [],
                "u19_c2": [],
                "u19_c3": [],
                "u19_loan": [],
            }
        )

    # Sort cleanly from GK (row 5) to SC (row 0), left to right
    slots.sort(key=lambda s: (-s["row"], s["col"]))
    for i, sl in enumerate(slots):
        sl["slotId"] = f"{prefix}_{i + 1}"
    return slots


def read_club_first_team_tactics(save, club_uid: int) -> list[dict]:
    """Read up to 3 active First Team tactics directly from tactics_man for the selected club."""
    tactics_out = []
    try:
        ctx = save._context
        info = ctx.info
        layout = tmod.find_tactics_layout(info.section_schemas.get(TACTICS_SECTION), info.build)
        save.clubs()
        ci = ctx.club_index()
        club = ci.club_by_uid.get(club_uid)
        if club is None:
            return []
        tids = [tm.team_id for tm in club.teams]
        lead = layout.user_signature[: tmod._SIGNATURE_LEAD_BYTES]
        width = len(layout.user_signature)
        known = set(tmod._known_signatures(layout))
        preset_sig = layout.preset_signature

        with ctx.section(TACTICS_SECTION) as tsec:
            stored_starts = tmod._stored_block_starts(tsec, layout, info.file_name)
            starts = tmod._block_starts(tsec, tids, layout)
            # Pick First Team block (team_slot == 0); fall back to first available team block
            first_team_tid = next((tm.team_id for tm in club.teams if tm.slot == 0 and tm.team_id in starts), None)
            if first_team_tid is None and starts:
                first_team_tid = sorted(starts.items(), key=lambda x: x[1])[0][0]
            if first_team_tid is None:
                return []

            bs = starts[first_team_tid]
            be = next((st for st in stored_starts if st > bs), len(tsec))
            cands = []
            at = tsec.find(lead, bs, be)
            while at >= 0:
                if at + width <= be:
                    cands.append(at)
                at = tsec.find(lead, at + 1, be)

            for idx, st in enumerate(cands):
                if len(tactics_out) >= 3:
                    break
                en = cands[idx + 1] if idx + 1 < len(cands) else be
                sig = tsec[st : st + width]
                if sig == preset_sig:
                    continue
                try:
                    rec = tmod._read_tactic_record(
                        tsec, st, en, layout, info.file_name, any_separator=(sig not in known)
                    )
                    if not rec.walk_complete or len(rec.slots) != 11:
                        continue
                    raw_codes = []
                    for sl in rec.slots:
                        if sl.in_possession_positions:
                            raw_codes.append(int(sl.in_possession_positions[0].raw))
                        else:
                            raw_codes.append(10)
                    slot_idx = len(tactics_out)
                    t_id = f"save-tactic-{slot_idx + 1}"
                    t_name = (rec.name or "").strip() or f"Tactic {slot_idx + 1}"
                    tactics_out.append(
                        {
                            "id": t_id,
                            "slotIndex": slot_idx,
                            "name": t_name,
                            "slots": raw_positions_to_grid_slots(raw_codes, prefix=f"st{slot_idx + 1}"),
                        }
                    )
                except Exception:
                    continue
    except Exception:
        return []
    return tactics_out


def read_local_fm27_manager_attributes(manager_name: str) -> dict | None:
    """Read the human manager's 14 coaching/mental attributes (1-20) from FM27 active_user_profile.xml if name matches."""
    if not manager_name:
        return None
    local_app = os.environ.get("LOCALAPPDATA") or ""
    if not local_app:
        return None
    candidates = [
        os.path.join(local_app, "Sports Interactive", "Football Manager 27", "Preferences", "version 6", "active_user_profile.xml"),
        os.path.join(local_app, "Sports Interactive", "Football Manager 27", "Preferences", "version 6", "profiles.xml"),
    ]
    import xml.etree.ElementTree as ET
    target_norm = " ".join(manager_name.strip().lower().split())
    ATTR_MAP = {
        "Ncha": "attacking",
        "Nchd": "defending",
        "Nchf": "fitness",
        "Npgs": "goalkeeping",
        "Nchm": "mental",
        "Ncsp": "setPieces",
        "Ncta": "tactical",
        "Ncte": "technical",
        "Npwy": "youngsters",
        "Npad": "adaptability",
        "Npde": "determination",
        "Npld": "discipline",
        "Npmm": "peopleMgmt",
        "Npmo": "motivating",
    }
    for xml_path in candidates:
        if not os.path.exists(xml_path):
            continue
        try:
            tree = ET.parse(xml_path)
            root = tree.getroot()
            for rec in root.iter("record"):
                if rec.attrib.get("id") != "MaPe":
                    continue
                vals = {}
                for child in rec:
                    cid = child.attrib.get("id")
                    if cid:
                        vals[cid] = child.attrib.get("value", "")
                full = " ".join(f"{vals.get('namf', '')} {vals.get('naml', '')}".strip().lower().split())
                if full and (full == target_norm or target_norm in full or full in target_norm):
                    attrs_out = {}
                    for xml_key, out_key in ATTR_MAP.items():
                        raw_v = vals.get(xml_key)
                        if raw_v is not None and str(raw_v).isdigit():
                            attrs_out[out_key] = int(raw_v)
                    if attrs_out:
                        return attrs_out
        except Exception:
            continue
    return None


def _scale_staff_attr_20(val):
    """Convert FM27 internal 0-100 staff attribute scale cleanly to 1-20 (or keep 1-20 if already <=20)."""
    if val is None:
        return None
    v = int(val)
    if v <= 20:
        return max(1, v)
    return max(1, min(20, round(v / 5)))


def read_club_analytics_and_manager(
    save, my_club_uid: int, chosen: dict, player_uid_to_unique: dict, nation_id_to_db: dict
) -> tuple[dict, dict]:
    """Extract Manager Profile (+ key staff) and Club Analytics (finances, season stats, injuries)."""
    # 1. Club finances (latest month)
    finances_out = None
    try:
        fins = [f for f in save.finances() if getattr(f, "club_uid", None) == my_club_uid]
        if fins:
            fins.sort(key=lambda x: str(getattr(x, "month", "") or ""))
            lf = fins[-1]
            finances_out = {
                "month": str(getattr(lf, "month", "") or ""),
                "balance": int(getattr(lf, "balance", 0) or 0),
                "transferBudgetAllocated": int(getattr(lf, "transfer_budget_allocated", 0) or 0),
                "transferBudgetRemaining": int(getattr(lf, "transfer_budget_remaining", 0) or 0),
                "wageBudgetWeekly": int(getattr(lf, "wage_budget_weekly", 0) or 0),
                "wagePayrollWeekly": int(getattr(lf, "wage_payroll_weekly", 0) or 0),
                "netTransfers": int(getattr(lf, "net_transfers", 0) or 0),
                "totalIncome": int(getattr(lf, "total_income", 0) or 0),
                "totalExpenditure": int(getattr(lf, "total_expenditure", 0) or 0),
            }
    except Exception:
        finances_out = None

    # 2. Player competitive season stats ('overall' preferred, fallback 'league')
    season_stats_out = []
    try:
        by_uid = {}
        for st in save.player_season_stats():
            if getattr(st, "club_uid", None) != my_club_uid:
                continue
            kind_str = str(getattr(st, "kind", "") or "").lower()
            if "overall" in kind_str and "calendar" not in kind_str:
                prio = 3
            elif kind_str.endswith("league") or kind_str == "league":
                prio = 2
            elif "non_competitive" not in kind_str and "calendar" not in kind_str and "international" not in kind_str:
                prio = 1
            else:
                continue
            p_uid = getattr(st, "player_uid", None)
            if p_uid is None:
                continue
            prev = by_uid.get(p_uid)
            if prev is None or prio > prev[0]:
                by_uid[p_uid] = (prio, st)

        for p_uid, (_, st) in by_uid.items():
            mins = int(getattr(st, "minutes", 0) or 0)
            apps = int(getattr(st, "rated_appearances", 0) or 0)
            starts = int(getattr(st, "starts", 0) or 0)
            subs = int(getattr(st, "substitute_appearances", 0) or 0)
            total_apps = max(apps, starts + subs)
            avg_r = getattr(st, "average_rating", None)
            season_stats_out.append(
                {
                    "uid": int(p_uid),
                    "uniqueId": int(player_uid_to_unique.get(p_uid, p_uid)),
                    "playerName": getattr(st, "player_name", "") or "",
                    "apps": total_apps,
                    "starts": starts,
                    "minutes": mins,
                    "avgRating": round(float(avg_r), 2) if avg_r is not None else None,
                    "goals": int(getattr(st, "goals", 0) or 0),
                    "xg": round(float(getattr(st, "expected_goals", 0) or 0), 2),
                    "assists": int(getattr(st, "assists", 0) or 0),
                    "xa": round(float(getattr(st, "expected_assists", 0) or 0), 2),
                    "cleanSheets": int(getattr(st, "clean_sheets", 0) or 0),
                    "yellowCards": int(getattr(st, "yellow_cards", 0) or 0),
                    "redCards": int(getattr(st, "red_cards", 0) or 0),
                }
            )
    except Exception:
        season_stats_out = []

    # 3. Injury history aggregated per player
    injuries_out = []
    try:
        inj_map = {}
        for inj in save.injuries():
            if getattr(inj, "club_uid", None) != my_club_uid:
                continue
            p_uid = getattr(inj, "player_uid", None)
            if p_uid is None:
                continue
            sev_obj = getattr(inj, "severity", None)
            sev_raw = int(getattr(sev_obj, "raw", 0) or 0)
            sev_lbl = getattr(getattr(sev_obj, "label", None), "name", None) or str(sev_raw)
            d_str = str(getattr(inj, "date", "") or "")
            entry = inj_map.get(p_uid)
            if entry is None:
                entry = {
                    "uid": int(p_uid),
                    "uniqueId": int(player_uid_to_unique.get(p_uid, p_uid)),
                    "playerName": getattr(inj, "player_name", "") or "",
                    "count": 0,
                    "majorCount": 0,
                    "latestDate": d_str,
                    "latestSeverity": sev_lbl.title(),
                }
                inj_map[p_uid] = entry
            entry["count"] += 1
            if sev_raw >= 2:
                entry["majorCount"] += 1
            if d_str >= entry["latestDate"]:
                entry["latestDate"] = d_str
                entry["latestSeverity"] = sev_lbl.title()
        injuries_out = sorted(inj_map.values(), key=lambda x: (-x["count"], -x["majorCount"], x["playerName"]))
    except Exception:
        injuries_out = []

    # 4. Human manager profile & key club staff
    manager_profile = {
        "name": chosen.get("managerName") or "",
        "uid": None,
        "uniqueId": None,
        "age": None,
        "birthDate": "",
        "nation": "",
        "clubUid": my_club_uid,
        "clubName": chosen.get("clubName") or "",
        "clubShortName": chosen.get("clubShortName") or "",
        "wageWeekly": None,
        "contractEnd": "",
        "personality": None,
        "keyStaff": [],
    }
    try:
        all_staff = list(save.staff())
        mgr_name_low = (chosen.get("managerName") or "").strip().lower()
        mgr_rec = None
        for st in all_staff:
            if getattr(st, "is_human_manager", False) and getattr(st, "club_uid", None) == my_club_uid:
                mgr_rec = st
                break
        if mgr_rec is None and mgr_name_low:
            for st in all_staff:
                st_name = (getattr(st, "name", "") or "").strip().lower()
                st_full = (getattr(st, "full_name", "") or "").strip().lower()
                if st_name == mgr_name_low or st_full == mgr_name_low:
                    mgr_rec = st
                    break
        if mgr_rec is not None:
            nat_db = nation_id_to_db.get(getattr(mgr_rec, "nation_id", None))
            pers = getattr(mgr_rec, "personality", None)
            manager_profile.update(
                {
                    "name": getattr(mgr_rec, "name", "") or manager_profile["name"],
                    "uid": int(getattr(mgr_rec, "uid", 0) or 0) or None,
                    "uniqueId": int(getattr(mgr_rec, "unique_id", 0) or 0) or None,
                    "age": int(getattr(mgr_rec, "age", 0) or 0) or None,
                    "birthDate": str(getattr(mgr_rec, "birth_date", "") or ""),
                    "nation": resolve_nation(nat_db) if nat_db else "",
                    "wageWeekly": int(getattr(mgr_rec, "wage", 0) or 0) or None,
                    "contractEnd": str(getattr(mgr_rec, "contract_end", "") or ""),
                    "personality": (
                        {
                            "adaptability": getattr(pers, "adaptability", None),
                            "ambition": getattr(pers, "ambition", None),
                            "loyalty": getattr(pers, "loyalty", None),
                            "pressure": getattr(pers, "pressure", None),
                            "professionalism": getattr(pers, "professionalism", None),
                            "sportsmanship": getattr(pers, "sportsmanship", None),
                            "temperament": getattr(pers, "temperament", None),
                        }
                        if pers is not None
                        else None
                    ),
                }
            )

        KEY_JOB_PRIORITY = {
            "ASSISTANT_MANAGER": (1, "Assistant Manager"),
            "DIRECTOR_OF_FOOTBALL": (2, "Director of Football"),
            "HEAD_OF_YOUTH_DEVELOPMENT": (3, "Head of Youth Dev"),
            "CHIEF_SCOUT": (4, "Chief Scout"),
            "MANAGER": (5, "Youth Manager"),
            "TECHNICAL_DIRECTOR": (6, "Technical Director"),
        }
        key_staff = []
        for st in all_staff:
            if getattr(st, "club_uid", None) != my_club_uid or getattr(st, "is_human_manager", False):
                continue
            job_obj = getattr(st, "job", None)
            job_name = getattr(getattr(job_obj, "label", None), "name", "") or ""
            if job_name not in KEY_JOB_PRIORITY:
                continue
            prio, role_lbl = KEY_JOB_PRIORITY[job_name]
            tslot = getattr(st, "team_slot", 0)
            if job_name == "MANAGER":
                role_lbl = "U21 Manager" if tslot == 1 else ("U18 Manager" if tslot >= 2 else "First Team Manager")
            elif job_name == "ASSISTANT_MANAGER" and tslot == 1:
                role_lbl = "U21 Asst. Manager"
                prio = 7
            elif job_name == "ASSISTANT_MANAGER" and tslot >= 2:
                role_lbl = "U18 Asst. Manager"
                prio = 8
            attrs = getattr(st, "attributes", None)
            key_staff.append(
                {
                    "prio": prio,
                    "uid": int(getattr(st, "unique_id", 0) or getattr(st, "uid", 0) or 0) or None,
                    "name": getattr(st, "name", "") or "",
                    "role": role_lbl,
                    "age": int(getattr(st, "age", 0) or 0) or None,
                    "jpa": _scale_staff_attr_20(getattr(attrs, "judging_player_ability", None)) if attrs else None,
                    "jpp": _scale_staff_attr_20(getattr(attrs, "judging_player_potential", None)) if attrs else None,
                    "tactical": _scale_staff_attr_20(getattr(attrs, "tactical_knowledge", None)) if attrs else None,
                    "people": _scale_staff_attr_20(getattr(attrs, "people_management", None)) if attrs else None,
                    "youth": _scale_staff_attr_20(getattr(attrs, "working_with_youngsters", None)) if attrs else None,
                }
            )
        key_staff.sort(key=lambda x: (x["prio"], x["name"]))
        manager_profile["keyStaff"] = [{k: v for k, v in item.items() if k != "prio"} for item in key_staff[:6]]
    except Exception:
        pass

    fm_attrs = read_local_fm27_manager_attributes(manager_profile.get("name") or "")
    if fm_attrs:
        manager_profile["fmAttributes"] = fm_attrs

    club_analytics = {
        "finances": finances_out,
        "seasonStats": season_stats_out,
        "injuries": injuries_out,
    }
    return manager_profile, club_analytics


def detect_club_squad_structure(club_row, club_players, save, nation_db_id):
    """
    Detect club's reserve (slot 1 -> canonical 'U21') and youth (slot >= 2 -> canonical 'U18')
    team display labels and age limits directly from the FM27 savegame:
    1) Affiliate B/II/Jong/2nd-team club names from club_row.teams
    2) Actual player age distribution in slot 1 and slot >= 2
    3) Nation defaults (e.g. Italy U20/U18, Spain B/U19, Germany II/U19, Norway 2. lag/U19, England U21/U18)
    """
    # Nation defaults: (slot1_label, slot1_max_age, slot2_label, slot2_max_age)
    # slot1_max_age=None means senior reserve team (B/II/2. lag) with no youth age cap.
    NATION_SQUAD_DEFAULTS = {
        765: ("U21", 21, "U18", 18),      # England
        776: ("U20", 20, "U18", 18),      # Italy (Primavera U20 + U18)
        796: ("B", None, "U19", 19),      # Spain
        771: ("II", None, "U19", 19),     # Germany
        769: ("B", None, "U19", 19),      # France
        788: ("B", None, "U19", 19),      # Portugal
        784: ("U21", 21, "U19", 19),      # Netherlands
        785: ("2. lag", None, "U19", 19), # Norway
        763: ("U19", 19, "U19", 19),      # Denmark (often only U19 or Reserves)
        797: ("U21", 21, "U19", 19),      # Sweden
        757: ("U21", 21, "U19", 19),      # Belgium
        755: ("II", None, "U19", 19),     # Austria
        798: ("U21", 21, "U19", 19),      # Switzerland
        791: ("U21", 21, "U18", 18),      # Scotland
        1651: ("U20", 20, "U18", 18),     # Brazil
        1649: ("U20", 20, "U18", 18),     # Argentina
    }
    s1_label, s1_max, s2_label, s2_max = NATION_SQUAD_DEFAULTS.get(
        nation_db_id, ("U21", 21, "U18", 18)
    )

    my_uid = getattr(club_row, "uid", None) if club_row is not None else None
    teams = tuple(getattr(club_row, "teams", ()) or ()) if club_row is not None else ()
    has_affiliate_s1 = False

    def extract_affiliate_badge(aff_name: str, fallback: str) -> str:
        name = (aff_name or "").strip()
        if not name:
            return fallback
        if re.search(r"\bJong\b", name, re.IGNORECASE):
            return "Jong"
        if re.search(r"\bCastilla\b", name, re.IGNORECASE):
            return "Castilla"
        if re.search(r"\bAtl[eè]tic\b", name, re.IGNORECASE):
            return "Atlètic"
        if re.search(r"\bII$", name):
            return "II"
        if re.search(r"\bB$", name):
            return "B"
        if re.search(r"\b2$", name):
            return "2. lag" if nation_db_id in (785, 763, 797) else "II"
        if re.search(r"\bU23\b", name, re.IGNORECASE):
            return "U23"
        if re.search(r"\bU21\b", name, re.IGNORECASE):
            return "U21"
        if re.search(r"\bU20\b", name, re.IGNORECASE):
            return "U20"
        if re.search(r"\bU19\b", name, re.IGNORECASE):
            return "U19"
        return fallback

    # 1) Check affiliate team on slot 1 (e.g. Dortmund II, Real Madrid Castilla, Jong Ajax, Rosenborg 2)
    for tm in teams:
        if getattr(tm, "slot", 0) == 1 and (
            getattr(tm, "is_affiliate", False)
            or (my_uid is not None and getattr(tm, "club_uid", None) != my_uid)
        ):
            has_affiliate_s1 = True
            aff_uid = getattr(tm, "club_uid", None)
            if aff_uid:
                try:
                    aff_rows = list(save.clubs().where(uid=aff_uid))
                    if aff_rows:
                        aff_name = aff_rows[0].short_name or aff_rows[0].name or ""
                        badge = extract_affiliate_badge(aff_name, s1_label)
                        s1_label = badge
                        if badge in ("U23", "U21", "U20", "U19"):
                            s1_max = int(badge[1:])
                        else:
                            s1_max = None
                except Exception:
                    pass
            break

    # 2) Inspect actual player ages in slot 1 and slot >= 2 in the savegame
    slot1_ages = sorted(
        int(p.age) for p in club_players if getattr(p, "team_slot", 0) == 1 and getattr(p, "age", None)
    )
    slot2_ages = sorted(
        int(p.age) for p in club_players if getattr(p, "team_slot", 0) >= 2 and getattr(p, "age", None)
    )

    def percentile_age(sorted_ages, pct=0.9):
        if not sorted_ages:
            return None
        idx = min(len(sorted_ages) - 1, int((len(sorted_ages) - 1) * pct))
        return sorted_ages[idx]

    if slot1_ages and not has_affiliate_s1:
        p90_s1 = percentile_age(slot1_ages, 0.9)
        max_s1 = slot1_ages[-1]
        if not slot2_ages and len(slot1_ages) >= 3:
            # Club only has First Team + ONE youth/reserve team (common: U19 or U20!)
            if p90_s1 <= 18 and max_s1 <= 18:
                s1_label, s1_max = "U18", 18
            elif p90_s1 <= 19 and max_s1 <= 19:
                s1_label, s1_max = "U19", 19
            elif p90_s1 == 20 and max_s1 <= 20:
                s1_label, s1_max = "U20", 20
            elif p90_s1 == 21 and max_s1 <= 21:
                s1_label, s1_max = "U21", 21
            elif p90_s1 <= 23 and max_s1 <= 23:
                s1_label, s1_max = "U23", 23
            elif p90_s1 >= 24 and nation_db_id in (785, 763, 797):
                s1_label, s1_max = "2. lag", None
        elif len(slot1_ages) >= 4 and s1_max is not None:
            # Refine age-capped reserve squad from actual ages when club has both slot 1 & slot 2
            if p90_s1 <= 19 and max_s1 <= 19 and nation_db_id != 765:
                s1_label, s1_max = "U19", 19
            elif p90_s1 == 20 and max_s1 <= 20 and nation_db_id != 765:
                s1_label, s1_max = "U20", 20
            elif p90_s1 >= 22 and max_s1 <= 23 and nation_db_id == 788:
                s1_label, s1_max = "U23", 23

    if slot2_ages:
        p90_s2 = percentile_age(slot2_ages, 0.9)
        max_s2 = slot2_ages[-1]
        count_19 = sum(1 for a in slot2_ages if a == 19)
        count_20 = sum(1 for a in slot2_ages if a == 20)
        if p90_s2 >= 20 or count_20 >= 2:
            s2_label, s2_max = "U20", 20
        elif p90_s2 >= 19 or count_19 >= 2:
            s2_label, s2_max = "U19", 19
        elif max_s2 <= 18 and s2_label == "U18":
            s2_label, s2_max = "U18", 18

    return (
        {"U21": s1_label, "U18": s2_label},
        {"U21": s1_max, "U18": s2_max},
    )


def emit_progress(percent: int, stage: str):
    """Emit structured progress markers on stderr without polluting stdout JSON."""
    try:
        sys.stderr.write(f"__GB_PROGRESS__:{int(percent)}:{stage}\n")
        sys.stderr.flush()
    except Exception:
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--save", required=True, help="Path to FM27 .fm save file")
    parser.add_argument("--shortlist", action="append", default=[], help="Optional .fmf shortlist path(s)")
    parser.add_argument("--club-uid", type=int, default=None, help="Optional managed club UID override")
    parser.add_argument("--list-managers", action="store_true", help="Only return all human managers/clubs quickly")
    args = parser.parse_args()

    patch_multimanager_summary_clock()

    if not args.list_managers:
        emit_progress(10, "opening")

    with fmsave.open(args.save, strict=False) as save:
        game_date_obj = getattr(save.info, "game_date", None)
        game_date_iso = game_date_obj.isoformat() if game_date_obj else "2026-07-01"
        all_managers = read_all_human_managers(save)

        if args.list_managers:
            payload = {
                "gameDate": game_date_iso,
                "managers": all_managers,
            }
            sys.stdout.buffer.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
            return

        if not all_managers:
            raise RuntimeError("Fant ingen aktiv spillerstyrt klubb i savefilen.")

        chosen = all_managers[0]
        if args.club_uid is not None:
            for m in all_managers:
                if int(m["clubUid"]) == int(args.club_uid):
                    chosen = m
                    break
            else:
                # Allow selecting any club in the save by UID if explicitly requested
                club_match = list(save.clubs().where(uid=args.club_uid))
                if club_match:
                    c0 = club_match[0]
                    chosen = {
                        "clubUid": int(c0.uid),
                        "clubName": c0.name,
                        "clubShortName": c0.short_name or c0.name,
                        "managerName": "",
                    }

        emit_progress(22, "club")
        my_club_uid = int(chosen["clubUid"])
        club_rows = list(save.clubs().where(uid=my_club_uid))
        my_club_nation_id = club_rows[0].nation_id if club_rows else 0
        nation_id_to_db = {n.nation_id: n.database_id for n in save.nations()}
        my_club_nation_db_id = nation_id_to_db.get(my_club_nation_id)
        detected_league_key = CLUB_NATION_TO_LEAGUE_KEY.get(my_club_nation_db_id, "premier_league")

        # Extract active First Team tactics (1-3) for this club
        club_tactics = read_club_first_team_tactics(save, my_club_uid)

        emit_progress(35, "players")
        all_players = save.players()
        club_players = list(all_players.where(club_uid=my_club_uid))
        loaned_out = [
            p
            for p in all_players
            if p.contract
            and p.contract.on_loan
            and p.contract.loan_parent_club_uid == my_club_uid
            and p.club_uid != my_club_uid
        ]

        # Calibrate Assistant Manager star anchor from top 14 first-team players
        first_team_cas = sorted(
            [
                p.ability.current
                for p in club_players
                if p.team_slot == 0 and p.ability and p.ability.current
            ],
            reverse=True,
        )
        top_slice = first_team_cas[:14] if first_team_cas else [135]
        squad_anchor = sum(top_slice) / len(top_slice)

        emit_progress(62, "stats")
        # Build global lightweight stats + injury lookup once for BOTH club players and shortlist targets
        global_stats_lookup = {}
        try:
            for st in save.player_season_stats():
                kind_str = str(getattr(st, "kind", "") or "").lower()
                if "overall" in kind_str and "calendar" not in kind_str:
                    prio = 3
                elif kind_str.endswith("league") or kind_str == "league":
                    prio = 2
                else:
                    continue
                p_uid = getattr(st, "player_uid", None)
                if p_uid is None:
                    continue
                prev = global_stats_lookup.get(p_uid)
                if prev is None or prio > prev["_prio"]:
                    avg_r = getattr(st, "average_rating", None)
                    starts = int(getattr(st, "starts", 0) or 0)
                    subs = int(getattr(st, "substitute_appearances", 0) or 0)
                    apps = max(int(getattr(st, "rated_appearances", 0) or 0), starts + subs)
                    global_stats_lookup[p_uid] = {
                        "_prio": prio,
                        "avgRating": round(float(avg_r), 2) if avg_r is not None else None,
                        "apps": apps,
                        "minutes": int(getattr(st, "minutes", 0) or 0),
                        "goals": int(getattr(st, "goals", 0) or 0),
                        "assists": int(getattr(st, "assists", 0) or 0),
                    }
        except Exception:
            global_stats_lookup = {}

        global_injury_lookup = {}
        try:
            for inj in save.injuries():
                p_uid = getattr(inj, "player_uid", None)
                if p_uid is not None:
                    global_injury_lookup[p_uid] = global_injury_lookup.get(p_uid, 0) + 1
        except Exception:
            global_injury_lookup = {}

        emit_progress(74, "squad")
        squad_records = []
        club_unique_ids = set()

        for p in club_players:
            slot = getattr(p, "team_slot", 0)
            if slot == 0:
                sq = "A-stall"
                st = "keep"
            elif slot == 1:
                sq = "U21"
                st = "talent"
            else:
                sq = "U18"
                st = "talent"
            rec = build_player_record(
                p,
                sq,
                st,
                my_club_uid,
                my_club_nation_id,
                squad_anchor,
                nation_id_to_db,
                stats_lookup=global_stats_lookup,
                injury_lookup=global_injury_lookup,
                default_contract_year=(game_date_obj.year + 2) if game_date_obj else 2029,
            )
            squad_records.append(rec)
            club_unique_ids.add(p.unique_id)

        my_team_id_to_slot = {}
        if club_rows:
            for tm in getattr(club_rows[0], "teams", ()) or ():
                my_team_id_to_slot[tm.team_id] = tm.slot

        squad_labels, squad_max_ages = detect_club_squad_structure(
            club_rows[0] if club_rows else None,
            club_players,
            save,
            my_club_nation_db_id,
        )
        youth_cap = squad_max_ages.get("U18") or 18
        reserve_cap = squad_max_ages.get("U21") or 21

        SENIOR_PLAYING_TIME_CODES = {1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18}

        for p in loaned_out:
            # Finn hvilken reell stall hos moderklubben lånespilleren tilhører (ALDRI 'Utlånt' — utlån er kun en status!):
            # 1) Eksplisitt U21/U20/U18/U19-lag i kontraktskjeden hvis satt (slot > 0)
            # 2) Avtalt spilletid på moderkontrakten (SquadStatus): senior spilletid -> A-stall
            # 3) Ellers etter klubbens reelle aldersgrenser (<= youth_cap -> U18, <= reserve_cap -> U21, ellers A-stall)
            inferred_home = ""
            contract = getattr(p, "contract", None)
            if contract is not None:
                for ch in getattr(contract, "chain", ()) or ():
                    if getattr(ch, "club_uid", None) == my_club_uid:
                        tid = getattr(ch, "team_id", None)
                        ts = my_team_id_to_slot.get(tid, 0)
                        if ts == 1:
                            inferred_home = "U21"
                            break
                        elif ts >= 2:
                            inferred_home = "U18"
                            break
                if not inferred_home:
                    ss = getattr(contract, "squad_status", None)
                    ss_raw = getattr(ss, "raw", None)
                    if ss_raw in SENIOR_PLAYING_TIME_CODES:
                        inferred_home = "A-stall"
            if not inferred_home:
                p_age = int(getattr(p, "age", 20) or 20)
                inferred_home = "U18" if p_age <= youth_cap else ("U21" if p_age <= reserve_cap else "A-stall")
            rec = build_player_record(
                p,
                inferred_home,
                "loan",
                my_club_uid,
                my_club_nation_id,
                squad_anchor,
                nation_id_to_db,
                home_squad=inferred_home,
                is_loaned=True,
                stats_lookup=global_stats_lookup,
                injury_lookup=global_injury_lookup,
                default_contract_year=(game_date_obj.year + 2) if game_date_obj else 2029,
            )
            squad_records.append(rec)
            club_unique_ids.add(p.unique_id)

        emit_progress(84, "manager")
        # Extract Manager Profile + Club Analytics (finances, competitive season stats, injuries)
        player_uid_to_unique = {}
        for p in club_players + loaned_out:
            p_uid = getattr(p, "uid", None)
            p_uniq = getattr(p, "unique_id", None) or p_uid
            if p_uid is not None and p_uniq is not None:
                player_uid_to_unique[int(p_uid)] = int(p_uniq)
            if p_uniq is not None:
                player_uid_to_unique[int(p_uniq)] = int(p_uniq)
        manager_profile, club_analytics = read_club_analytics_and_manager(
            save, my_club_uid, chosen, player_uid_to_unique, nation_id_to_db
        )

        # Resolve optional .fmf shortlists against the save's player database
        shortlist_records = []
        shortlist_summaries = []
        if args.shortlist:
            emit_progress(92, "shortlists")
            by_unique_id = {p.unique_id: p for p in all_players}
            for sl_path in args.shortlist:
                if not sl_path or not os.path.exists(sl_path):
                    continue
                sl_name, uids = parse_fmf_shortlist(sl_path)
                matched = 0
                for u in uids:
                    if u in club_unique_ids:
                        continue
                    p = by_unique_id.get(u)
                    if p is None:
                        continue
                    rec = build_player_record(
                        p,
                        "Shortlist",
                        "target",
                        my_club_uid,
                        my_club_nation_id,
                        squad_anchor,
                        nation_id_to_db,
                        shortlist_name=sl_name,
                        stats_lookup=global_stats_lookup,
                        injury_lookup=global_injury_lookup,
                        default_contract_year=(game_date_obj.year + 2) if game_date_obj else 2029,
                    )
                    shortlist_records.append(rec)
                    matched += 1
                shortlist_summaries.append(
                    {"name": sl_name, "file": os.path.basename(sl_path), "totalUids": len(uids), "matched": matched}
                )

        payload = {
            "meta": {
                "game": getattr(save.info, "game", "FM27"),
                "build": getattr(save.info, "build", ""),
                "gameDate": game_date_iso,
                "clubUid": my_club_uid,
                "clubName": chosen["clubName"],
                "clubShortName": chosen["clubShortName"],
                "clubNation": resolve_nation(my_club_nation_db_id),
                "leagueKey": detected_league_key,
                "squadLabels": squad_labels,
                "squadMaxAges": squad_max_ages,
                "managerName": chosen["managerName"],
                "managedClubs": all_managers,
                "tacticsCount": len(club_tactics),
                "squadCount": len(squad_records),
                "shortlistCount": len(shortlist_records),
                "shortlists": shortlist_summaries,
            },
            "tactics": club_tactics,
            "managerProfile": manager_profile,
            "clubAnalytics": club_analytics,
            "squad": squad_records,
            "shortlist": shortlist_records,
        }
        emit_progress(99, "done")
        sys.stdout.buffer.write(json.dumps(payload, ensure_ascii=False).encode("utf-8"))


if __name__ == "__main__":
    main()
